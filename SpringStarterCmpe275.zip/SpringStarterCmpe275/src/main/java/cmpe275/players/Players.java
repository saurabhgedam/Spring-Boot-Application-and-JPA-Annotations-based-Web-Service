package cmpe275.players;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Players {

	
	int age;
	@Id
	String name;
	String team;
	
	public Players()
	{
		
	}
	
	public Players(String name, int age, String team)
	{
		this.name = name;
		this.age=age;
		this.team = team;
	}
	
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTeam() {
		return team;
	}
	public void setTeam(String team) {
		this.team = team;
	}
	
}