package cmpe275.players;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;




@RestController
public class PlayerController {
	
	@Autowired
	private PlayerService playerServiceObj;
	
	@RequestMapping("/players")
	public List<Players> showAll()
	{
		return playerServiceObj.showAll();		
	}
	
	@RequestMapping("/players/{foo}")
	public Players select(@PathVariable("foo") String name)
	{
		return playerServiceObj.find(name);		
	}
	
	@RequestMapping(method=RequestMethod.POST, value="/players")
	public void addPlayer(@RequestBody Players player)
	{
		playerServiceObj.addPlayer(player);
	}
	
	@RequestMapping(method=RequestMethod.PUT, value="/players/{foo}")
	public void updatePlayer(@PathVariable("foo") String name, @RequestBody Players player)
	{
		playerServiceObj.updatePlayer(player);
	}

	@RequestMapping(method=RequestMethod.DELETE, value="/players/{foo}")
	public void deletePlayer(@PathVariable("foo") String name)
	{		
		playerServiceObj.deletePlayer(name);
	}

} 