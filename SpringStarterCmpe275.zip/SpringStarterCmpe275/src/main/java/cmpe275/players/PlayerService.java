package cmpe275.players;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;

@Service
public class PlayerService {
	
	
	Players players;
	@Autowired
	PlayerDataService pService;
	
	public List<Players> playersList = new ArrayList<> ();
	
	 	 	
	public List<Players> showAll()
	{
		List<Players> playersList = new ArrayList<>();
		pService.findAll().forEach(playersList::add);
		return playersList;
	}
	
	public Players find(String name)
	{
		return pService.findOne(name);
	}

	public void addPlayer(Players player) {
		pService.save(player);
	}
	
	public void updatePlayer(Players player)
	{
		pService.save(player);
	}

	public void deletePlayer(String name) {
		pService.delete(name);
		
	} 
	
}
