package cmpe275.players;
import org.springframework.data.repository.CrudRepository;

public interface PlayerDataService extends CrudRepository <Players, String> {
 
	
	//this now has all the methods of crudrepository
}
