package com.example;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import cmpe275.players.PlayerController;
import cmpe275.players.PlayerService;
import cmpe275.players.Players;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
public class SpringStarterCmpe275ApplicationTests {

	MockMvc mockMvc;
	Players player;

	@Mock
	PlayerService service;

	@InjectMocks
	PlayerController controller;


	@Before
	public void init(){
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders
				.standaloneSetup(controller).build();		
	}

	@Test
	public void test_get_by_id_success() throws Exception {

		Players player = new Players("Steven",31,"abc");
		when(service.find("Steven")).thenReturn(player);

		mockMvc.perform(get("/players/Steven"))
		.andExpect(status().isOk())
		.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
		.andExpect(jsonPath("$.name", is("Steven")))
		.andExpect(jsonPath("$.age", is(31)))
		.andExpect(jsonPath("$.team", is("abc")));
		verify(service, times(1)).find("Steven");
		verifyNoMoreInteractions(service);			
	}
}